// متغيرات الرسم
let canvas = null;
let ctx = null;
let isDrawing = false;
let drawColor = '#000000';
let drawLineWidth = 3;

// تهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    setDateToday();
    initializeCanvas();
});

// تهيئة لوحة الرسم
function initializeCanvas() {
    const designCanvas = document.getElementById('designCanvas');
    
    // إنشاء عنصر canvas
    canvas = document.createElement('canvas');
    canvas.width = designCanvas.clientWidth - 40;
    canvas.height = 300;
    canvas.style.border = '2px solid #87CEEB';
    canvas.style.borderRadius = '10px';
    canvas.style.cursor = 'crosshair';
    canvas.style.display = 'block';
    canvas.style.margin = '0 auto';
    canvas.style.backgroundColor = 'white';
    
    designCanvas.innerHTML = '';
    designCanvas.appendChild(canvas);
    
    ctx = canvas.getContext('2d');
    
    // معالجات الرسم
    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseout', stopDrawing);
    
    // معالجات اللمس
    canvas.addEventListener('touchstart', handleTouchStart);
    canvas.addEventListener('touchmove', handleTouchMove);
    canvas.addEventListener('touchend', stopDrawing);
}

// بداية الرسم
function startDrawing(e) {
    isDrawing = true;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    ctx.beginPath();
    ctx.moveTo(x, y);
}

// الرسم
function draw(e) {
    if (!isDrawing) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    ctx.strokeStyle = drawColor;
    ctx.lineWidth = drawLineWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineTo(x, y);
    ctx.stroke();
}

// نهاية الرسم
function stopDrawing() {
    isDrawing = false;
    ctx.closePath();
}

// معالج بداية اللمس
function handleTouchStart(e) {
    e.preventDefault();
    const touch = e.touches[0];
    const rect = canvas.getBoundingClientRect();
    const x = touch.clientX - rect.left;
    const y = touch.clientY - rect.top;
    
    isDrawing = true;
    ctx.beginPath();
    ctx.moveTo(x, y);
}

// معالج حركة اللمس
function handleTouchMove(e) {
    e.preventDefault();
    if (!isDrawing) return;
    
    const touch = e.touches[0];
    const rect = canvas.getBoundingClientRect();
    const x = touch.clientX - rect.left;
    const y = touch.clientY - rect.top;
    
    ctx.strokeStyle = drawColor;
    ctx.lineWidth = drawLineWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineTo(x, y);
    ctx.stroke();
}

// تعيين لون الرسم
function setDrawColor(color) {
    drawColor = color;
}

// مسح لوحة الرسم
function clearDesign() {
    if (confirm('هل تريد/تريدين مسح الرسم؟')) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
}

// ضبط التاريخ إلى اليوم
function setDateToday() {
    const dateInput = document.getElementById('activityDate');
    const today = new Date().toISOString().split('T')[0];
    dateInput.value = today;
}

// تصوير الورقة
function takeScreenshot() {
    const element = document.querySelector('.container');
    
    if (typeof html2canvas !== 'undefined') {
        html2canvas(element, {
            scale: 2,
            useCORS: true,
            logging: false,
            backgroundColor: '#ffffff'
        }).then(canvas => {
            const link = document.createElement('a');
            const studentName = document.getElementById('studentName').value || 'الطالب';
            link.href = canvas.toDataURL('image/png');
            link.download = `ألعابي_المنسوجة_${studentName}.png`;
            link.click();
            alert('✅ تم تحميل الصورة بنجاح!');
        }).catch(err => {
            alert('❌ حدث خطأ في تصوير الورقة. جرّب/جرّبي الطباعة بدلاً من ذلك.');
            console.error(err);
        });
    } else {
        alert('❌ ميزة التصوير غير متوفرة. جرّب/جرّبي الطباعة بدلاً من ذلك.');
    }
}

// طباعة الورقة
function printActivity() {
    window.print();
}

// إعادة تعيين الكل
function resetAll() {
    if (confirm('هل تريد/تريدين إعادة تعيين جميع البيانات؟')) {
        // مسح جميع الحقول
        document.querySelectorAll('input[type="text"], textarea').forEach(input => {
            input.value = '';
        });
        
        // مسح الرسم
        clearDesign();
        
        // مسح الرموز التشجيعية
        document.getElementById('encouragementDisplay').innerHTML = '';
        
        // إعادة تعيين التاريخ
        setDateToday();
        
        window.scrollTo(0, 0);
        alert('✅ تم إعادة تعيين الورقة بنجاح!');
    }
}

// إضافة رموز تشجيعية
function addEncouragement(emoji) {
    const encouragementDisplay = document.getElementById('encouragementDisplay');
    const encouragementSpan = document.createElement('span');
    encouragementSpan.textContent = emoji;
    encouragementSpan.style.marginRight = '5px';
    encouragementSpan.style.cursor = 'pointer';
    
    // إضافة معالج الضغط لحذف الرمز
    encouragementSpan.addEventListener('click', function() {
        encouragementSpan.remove();
    });
    
    encouragementDisplay.appendChild(encouragementSpan);
}

// حفظ تلقائي
setInterval(function() {
    const studentName = document.getElementById('studentName').value;
    if (studentName) {
        const autoSaveData = {
            studentName: studentName,
            thinkText: document.getElementById('thinkText').value,
            shareText: document.getElementById('shareText').value,
            timestamp: new Date().toLocaleString('ar-SA')
        };
        localStorage.setItem('autoSave_' + studentName, JSON.stringify(autoSaveData));
    }
}, 300000); // كل 5 دقائق
