// متغيرات التحريك
let draggedItem = null;
let offsetX = 0;
let offsetY = 0;

// تهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    setDateToday();
});

// ضبط التاريخ إلى اليوم
function setDateToday() {
    const dateInput = document.getElementById('activityDate');
    const today = new Date().toISOString().split('T')[0];
    dateInput.value = today;
}

// إضافة شكل عند الضغط على الزر
function addStamp(shape) {
    const stampCanvas = document.getElementById('stampCanvas');
    const stampItem = document.createElement('div');
    
    stampItem.className = 'stamp-item';
    stampItem.textContent = shape;
    
    // موضع عشوائي في المنطقة
    const randomX = Math.random() * Math.max(0, stampCanvas.clientWidth - 80);
    const randomY = Math.random() * Math.max(0, stampCanvas.clientHeight - 80);
    
    stampItem.style.position = 'absolute';
    stampItem.style.left = randomX + 'px';
    stampItem.style.top = randomY + 'px';
    stampItem.style.cursor = 'grab';
    stampItem.style.userSelect = 'none';
    
    // معالج الماوس - بداية التحريك
    stampItem.addEventListener('mousedown', startDrag);
    
    // معالج اللمس - بداية التحريك
    stampItem.addEventListener('touchstart', startDrag);
    
    function startDrag(e) {
        e.preventDefault();
        draggedItem = stampItem;
        
        const rect = stampItem.getBoundingClientRect();
        const canvasRect = stampCanvas.getBoundingClientRect();
        
        // الحصول على إحداثيات الماوس أو اللمس
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        offsetX = clientX - rect.left;
        offsetY = clientY - rect.top;
        
        stampItem.style.cursor = 'grabbing';
        stampItem.style.zIndex = 1000;
        stampItem.style.opacity = '0.8';
        
        // معالج التحريك
        function onMove(moveEvent) {
            if (draggedItem === stampItem) {
                moveEvent.preventDefault();
                
                const moveClientX = moveEvent.touches ? moveEvent.touches[0].clientX : moveEvent.clientX;
                const moveClientY = moveEvent.touches ? moveEvent.touches[0].clientY : moveEvent.clientY;
                
                const newX = moveClientX - canvasRect.left - offsetX;
                const newY = moveClientY - canvasRect.top - offsetY;
                
                // التأكد من عدم الخروج من المنطقة
                const maxX = canvasRect.width - 80;
                const maxY = canvasRect.height - 80;
                
                stampItem.style.left = Math.max(0, Math.min(newX, maxX)) + 'px';
                stampItem.style.top = Math.max(0, Math.min(newY, maxY)) + 'px';
            }
        }
        
        // معالج نهاية التحريك
        function onEnd() {
            if (draggedItem === stampItem) {
                draggedItem = null;
                stampItem.style.cursor = 'grab';
                stampItem.style.zIndex = 'auto';
                stampItem.style.opacity = '1';
            }
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('touchmove', onMove);
            document.removeEventListener('mouseup', onEnd);
            document.removeEventListener('touchend', onEnd);
        }
        
        document.addEventListener('mousemove', onMove);
        document.addEventListener('touchmove', onMove, { passive: false });
        document.addEventListener('mouseup', onEnd);
        document.addEventListener('touchend', onEnd);
    }
    
    // إضافة زر حذف
    const deleteBtn = document.createElement('span');
    deleteBtn.className = 'delete-btn';
    deleteBtn.textContent = '✕';
    deleteBtn.style.pointerEvents = 'auto';
    deleteBtn.onclick = function(e) {
        e.stopPropagation();
        stampItem.remove();
    };
    
    stampItem.appendChild(deleteBtn);
    
    // إضافة معالج الضغط المزدوج لحذف الشكل
    stampItem.addEventListener('dblclick', function() {
        stampItem.remove();
    });
    
    stampCanvas.appendChild(stampItem);
}

// مسح جميع الأشكال المطبوعة
function clearStamps() {
    if (confirm('هل تريدين مسح جميع الأشكال المطبوعة؟')) {
        const stampCanvas = document.getElementById('stampCanvas');
        stampCanvas.innerHTML = '';
    }
}

// تصوير الورقة
function takeScreenshot() {
    const element = document.querySelector('.container');
    
    if (typeof html2canvas !== 'undefined') {
        html2canvas(element, {
            scale: 2,
            useCORS: true,
            logging: false,
            backgroundColor: '#ffffff'
        }).then(canvas => {
            const link = document.createElement('a');
            const studentName = document.getElementById('studentName').value || 'الطالبة';
            link.href = canvas.toDataURL('image/png');
            link.download = `أطبع_بوجداني_${studentName}.png`;
            link.click();
            alert('✅ تم تحميل الصورة بنجاح!');
        }).catch(err => {
            alert('❌ حدث خطأ في تصوير الورقة. جرّبي الطباعة بدلاً من ذلك.');
            console.error(err);
        });
    } else {
        alert('❌ ميزة التصوير غير متوفرة. جرّبي الطباعة بدلاً من ذلك.');
    }
}

// طباعة الورقة
function printActivity() {
    window.print();
}

// إعادة تعيين الكل
function resetAll() {
    if (confirm('هل تريدين إعادة تعيين جميع البيانات؟')) {
        // مسح جميع الحقول
        document.querySelectorAll('input[type="text"], textarea').forEach(input => {
            input.value = '';
        });
        
        // مسح الأشكال المطبوعة
        clearStamps();
        
        // إعادة تعيين التاريخ
        setDateToday();
        
        // إعادة تعيين التقييم
        document.querySelectorAll('input[type="radio"]').forEach(radio => {
            radio.checked = false;
        });
        
        window.scrollTo(0, 0);
        alert('✅ تم إعادة تعيين الورقة بنجاح!');
    }
}

// حفظ تلقائي
setInterval(function() {
    const studentName = document.getElementById('studentName').value;
    if (studentName) {
        const autoSaveData = {
            studentName: studentName,
            observationText: document.getElementById('observationText').value,
            timestamp: new Date().toLocaleString('ar-SA')
        };
        localStorage.setItem('autoSave_' + studentName, JSON.stringify(autoSaveData));
    }
}, 300000); // كل 5 دقائق
